# CV_Inteligent
Bachelor degree project: CV Inteligent (android app)

Trello: https://trello.com/b/vFag1p6z/licenta
Trello BUGs: https://trello.com/b/W9pLnkAE/bugs
